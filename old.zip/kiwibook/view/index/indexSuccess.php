<div id="Head">
    Bienvenue sur l'index !
    <a href=kiwibook.php?action=login>Connectez vous !</a>
</div>