<form method="post" action="kiwibook.php?action=login">
    <div class="form-group">
        <label class="col-sm-4">Pseudo:</label>
        <div class="col-sm-8">
            <input type="text" name="pseudo" class="form-control"/>
        </div>
    </div>
    <div class="form-group">
        <label class="col-sm-4">Password:</label>
        <div class="col-sm-8">
            <input type="password" name="password" class="form-control"/>
        </div>
    </div>
    <div class="form-group">
        <input type="submit" name="submit" value="Valider" class="col-sm-12">
    </div>
</form>