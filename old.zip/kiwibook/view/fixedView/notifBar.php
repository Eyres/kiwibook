<?php if ($context->message) { ?>
    <div class="bandeau" id="message">
        <?php echo $context->message; ?>
    </div>
<?php } ?>