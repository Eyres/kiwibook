<div id="chat-window" class="hidden">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-2">
                <img class="img-responsive" src="#">
            </div>
            <div class="col-sm-3">
                <h5>Nom prenom -> destinataire nom prenom</h5>
            </div>
            <div class="col-sm-7">
                <p>super texte du message</p>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-sm-2">
            <img class="img-responsive" src="#">
        </div>
        <div class="col-sm-3">
            <h5>Nom prenom -> destinataire nom prenom</h5>
        </div>
        <div class="col-sm-7">
            <p>super texte du message</p>
        </div>
    </div>


    <div class="row">
        <div class="col-sm-2">
            <img class="img-responsive" src="#">
        </div>
        <div class="col-sm-3">
            <h5>Nom prenom -> destinataire nom prenom</h5>
        </div>
        <div class="col-sm-7">
            <p>super texte du message</p>
        </div>
    </div>
</div>
