<form method="post" action="kiwibook.php?action=login">
    <p>
        <label>Pseudo</label> : <input type="text" name="pseudo"/><br>
        <label>Password</label> : <input type="password" name="password"/><br>
        <label><input type="submit" name="submit" value="Valider"></label><br>
    </p>
</form>


